// These modules are licensed to you
#define QT_MODULE_TOOLS
#define QT_MODULE_KERNEL
#define QT_MODULE_WIDGETS
#define QT_MODULE_DIALOGS
#define QT_MODULE_ICONVIEW
#define QT_MODULE_WORKSPACE
#define QT_MODULE_NETWORK
#define QT_MODULE_CANVAS
#define QT_MODULE_TABLE
#define QT_MODULE_XML
